 hive -f ~/workspace/tde/src/main/resources/hive/execution-scripts/insert-query-export/export_TDE_EXPORT.hql
 hadoop fs -getmerge /user/ZHUANL2_D2-TDBFG/output/data/tdeexport/* /home/D2-TDBFG/ZHUANL2_D2-TDBFG/lz/tdeexport/export_CRV_DETAIL_DATA.csv

