

/**
 * -----------------------------------------------------------------------------
 * 
 *	Make TDE file and publish TDE file to Tableau Server
 *	Tableau SDK API 
 * -----------------------------------------------------------------------------
 */
package com.td.tableau.tde;

import com.tableausoftware.TableauException;
import com.tableausoftware.common.*;
import com.tableausoftware.extract.*;
import com.tableausoftware.server.*;
import com.opencsv.CSVReader;

import java.io.FileReader;
import java.io.IOException;

public final class MakeAndPublishTDE {
    /**
     * -------------------------------------------------------------------------
     * Helper Functions
     * -------------------------------------------------------------------------
     */
	
	private static String TDEFileName = "CRV_DETAIL_DATA.tde";
	private static String TDEDataSource = "CRV_DETAIL_DS";
	private static String CSVFile = "/home/cloudera/lz/tdeexport/export_CRV_DETAIL_DATA.csv";

    // Define the table's schema
    private static TableDefinition makeTableDefinition() throws TableauException {
        TableDefinition tableDef = new TableDefinition();
        tableDef.setDefaultCollation(Collation.EN_GB);

        tableDef.addColumn("Tran_Product_Code",    Type.CHAR_STRING);
        tableDef.addColumn("Tran_Centre",          Type.CHAR_STRING);
        tableDef.addColumn("Tran_Amt_Vol",         Type.INTEGER);
        tableDef.addColumn("Podium_Delivery_Date", Type.CHAR_STRING);

        return tableDef;
    }

    // Print a Table's schema to stderr.
    private static void printTableDefinition(TableDefinition tableDef) throws TableauException {
        int numColumns = tableDef.getColumnCount();
        for ( int i = 0; i < numColumns; ++i ) {
            Type type = tableDef.getColumnType(i);
            String name = tableDef.getColumnName(i);

            System.err.format("Column %d: %s (%#06x)\n", i, name, type.getValue());
        }
    }

    // Insert a new row of data
    private static void insertData(Table table, String[] line) throws TableauException {
        TableDefinition tableDef = table.getTableDefinition();
        Row row = new Row(tableDef);

//        row.setDateTime(  0, 2012, 7, 3, 11, 40, 12, 4550); // Purchased
//        row.setCharString(1, "Beans");                      // Product
//        row.setString(    2, "uniBeans");                   // uProduct
//        row.setDouble(    3, 1.08);                         // Price
//        row.setDate(      6, 2029, 1, 1);                   // Expiration date
//        row.setCharString(7, "Bohnen");                     // Produkt
        
    	row.setCharString(0, line[0]); 						// Tran_Product_Code
    	row.setCharString(1, line[1]); 						// Tran_Centre
    	row.setLongInteger(2, Long.parseLong(line[2])); 		// Tran_Amt_Vol
    	row.setCharString(3, line[3]); 						// Podium_Delivery_Date
        
    	table.insert(row);
    }

    public static void readCSVFile(Table table, String csvFile) {


        CSVReader reader = null;
        try {
            reader = new CSVReader(new FileReader(csvFile));
            String[] line;
            long count=0;
            while ((line = reader.readNext()) != null) {
                System.out.println(++count + "- Country [id= " + line[0] + ", code= " + line[1] + " , name=" + line[2]  + " , podium_delivery_date=" + line[3] + "]");
            	insertData(table, line);
            }
        } catch (IOException | TableauException e) {
            e.printStackTrace();
        }


    }
    
     /**
     * -------------------------------------------------------------------------
     * Main
     * -------------------------------------------------------------------------
     */
    public static void main( String[] args ) {

    	
        // Create Extract
        try {
            // Initialize Tableau Extract API
            ExtractAPI.initialize();

            try (Extract extract = new Extract(MakeAndPublishTDE.TDEFileName)) {

                Table table;
                if (!extract.hasTable("Extract")) {
                    // Table does not exist; create it
                    TableDefinition tableDef = makeTableDefinition();
                    table = extract.addTable("Extract", tableDef);
                }
                else {
                    // Open an existing table to add more rows
                    table = extract.openTable("Extract");
                }

                TableDefinition tableDef = table.getTableDefinition();
                printTableDefinition(tableDef);
                
                readCSVFile(table, MakeAndPublishTDE.CSVFile);
                
            }

            // Clean up Tableau Extract API
            ExtractAPI.cleanup();
        }
        catch (Throwable t) {
            t.printStackTrace(System.err);
        }

        //start of extract to server
        // Publish Extract
        try {
            // Initialize Tableau Server API
            ServerAPI.initialize();

            // Create the server connection object
            ServerConnection serverConnection = new ServerConnection();

            // Connect to the server
            //serverConnection.connect("http://localhost", "username", "password", "siteID");
            //serverConnection.connect("http://192.168.1.213", "lzhuang", "p@$$w0rd!", "default");
            serverConnection.connect("http://win2012r2-oryc9.dynamic.cr.cloud.td.com", "zhuanl2", "zhuanl2", "LanceSite");

            // Publish order-java.tde to the server under the default project with name Order-java
            //serverConnection.publishExtract("order2-java.tde", "default", "Order2-java", false);
            serverConnection.publishExtract(MakeAndPublishTDE.TDEFileName, "Default", MakeAndPublishTDE.TDEDataSource, false);
            
            // Disconnect from the server
            serverConnection.disconnect();

            // Destroy the server connection object
            serverConnection.close();

            // Clean up Tableau Server API
            ServerAPI.cleanup();
        }
        catch (TableauException e) {
            // Handle the exception depending on the type of exception received

            switch(Result.enumForValue(e.getErrorCode())) {
            case INTERNAL_ERROR:
                System.err.println("INTERNAL_ERROR - Could not parse the response from the server.");
                break;
            case INVALID_ARGUMENT:
                System.err.println("INVALID_ARGUMENT - " + e.getMessage());
                break;
            case CURL_ERROR:
                System.err.println("CURL_ERROR - " + e.getMessage());
                break;
            case SERVER_ERROR:
                System.err.println("SERVER_ERROR - " + e.getMessage());
                break;
            case NOT_AUTHENTICATED:
                System.err.println("NOT_AUTHENTICATED - " + e.getMessage());
                break;
            case BAD_PAYLOAD:
                System.err.println("BAD_PAYLOAD - Unknown response from the server. Make sure this version of Tableau API is compatible with your server.");
                break;
            case INIT_ERROR:
                System.err.println("INIT_ERROR - " + e.getMessage());
                break;
            case UNKNOWN_ERROR:
            default:
                System.err.println("An unknown error occured.");
                break;
            }
            e.printStackTrace(System.err);
        }
        // end of extract to server        
    }

}
