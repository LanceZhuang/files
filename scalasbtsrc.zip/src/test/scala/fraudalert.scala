object fraudalert {


  // Complete the activityNotifications function below.
  def activityNotifications(expenditure: Array[Int], d: Int): Int = {
    var segArr = new Array[Int](d)
    var alertCount = 0
    for (i <- d until expenditure.length) {
      for (j <- i-d until i) segArr(j-i+d) = expenditure(j)
      var sorted: Array[Int] = segArr.sorted
      var medianPrice  = if (d%2 == 1) sorted(d/2) else (sorted(d/2)+sorted(d/2-1))/2.0
//      sorted.foreach(printf("%d ",_))
//      print(medianPrice); print("")
//      print(expenditure(i))
//      println
      alertCount += (if (expenditure(i) >= 2*medianPrice) 1 else 0)
    }
//    println(alertCount)
  return alertCount
  }

  def main(args: Array[String]) {
    val stdin = scala.io.StdIn

//    val printWriter = new PrintWriter(sys.env("OUTPUT_PATH"))

    val nd = stdin.readLine.split(" ")

    val n = nd(0).trim.toInt

    val d = nd(1).trim.toInt

    val expenditure = stdin.readLine.split(" ").map(_.trim.toInt)
    val result = activityNotifications(expenditure, d)
  println(result)
//    printWriter.println(result)

//    printWriter.close()
  }
}
