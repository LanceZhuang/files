import java.io._
import java.math._
import java.security._
import java.text._
import java.util._
import java.util.concurrent._
import java.util.function._
import java.util.regex._
import java.util.stream._
import scala.collection.immutable._
import scala.collection.mutable._
import scala.collection.concurrent._
import scala.concurrent._
import scala.io._
import scala.math._
import scala.sys._
import scala.util.matching._
import scala.reflect._



object Result4 {

  /*
   * Complete the 'maxShared' function below.
   *
   * The function is expected to return an INTEGER.
   * The function accepts WEIGHTED_INTEGER_GRAPH friends as parameter.
   */

  /*
   * For the weighted graph, <name>:
   *
   * 1. The number of nodes is <name>Nodes.
   * 2. The number of edges is <name>Edges.
   * 3. An edge exists between <name>From[i] and <name>To[i]. The weight of the edge is <name>Weight[i].
   *
   */

  def maxShared(friendsNodes: Int, friendsFrom: Array[Int], friendsTo: Array[Int], friendsWeight: Array[Int]): Int = {
return 1
  }

}

object Solution {
  def main(args: Array[String]) {
    val printWriter = new PrintWriter(sys.env("OUTPUT_PATH"))

    val Array(friendsNodes, friendsEdges) = StdIn.readLine().replaceAll("\\s+$", "").split(" ").map(_.toInt)

    val friendsFrom = Array.ofDim[Int](friendsEdges)
    val friendsTo = Array.ofDim[Int](friendsEdges)
    val friendsWeight = Array.ofDim[Int](friendsEdges)

    for (i <- 0 until friendsEdges) {
      val friendsFromToWeight = StdIn.readLine().replaceAll("\\s+$", "").split(" ")

      friendsFrom(i) = friendsFromToWeight(0).toInt
      friendsTo(i) = friendsFromToWeight(1).toInt
      friendsWeight(i) = friendsFromToWeight(2).toInt
    }

    val result = Result4.maxShared(friendsNodes, friendsFrom, friendsTo, friendsWeight)

    printWriter.println(result)

    printWriter.close()
  }
}
