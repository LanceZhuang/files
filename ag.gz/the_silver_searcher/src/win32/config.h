#define HAVE_LZMA_H
#define HAVE_PTHREAD_H
