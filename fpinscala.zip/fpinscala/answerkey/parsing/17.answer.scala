See a fully worked implementation in `instances/Sliceable.scala` in the answers.
