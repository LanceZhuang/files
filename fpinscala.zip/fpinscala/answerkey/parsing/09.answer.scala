See full implementation in JSON.scala
